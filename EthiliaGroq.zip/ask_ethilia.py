import requests, sys, os

api_key = os.getenv("GROQ_API_KEY")
if not api_key:
    print("❌ Set your GROQ_API_KEY first: export GROQ_API_KEY='gsk_xxx'")
    exit(1)

headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

data = {
    "model": "llama3-70b-8192",
    "messages": [
        {"role": "system", "content": "You're Ethilia, a clever, philosophical AI."},
        {"role": "user", "content": sys.argv[1]}
    ]
}

res = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)

try:
    print(res.json()['choices'][0]['message']['content'])
except KeyError:
    print("❌ Network/API error:", res.status_code, res.reason)
    print("📦 Response:", res.text)
